﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KeuSpawner : MonoBehaviour {

    public GameObject[] keulen;
    public Vector3 spawnPosition;
    public float spawnWait;
    public int startWait;
    
   
	// Use this for initialization
	void Start () {
            
            StartCoroutine(KeulenSpawner());

            
         
	}
	
	// Update is called once per frame
	void Update () {

        spawnWait = 10.0f;


	}

    IEnumerator KeulenSpawner(){

        yield return new WaitForSeconds(startWait);

        while(true){

            spawnPosition = new Vector3(Random.Range(-100.0f, 100.0f), 1.0f, Random.Range(-100.0f, 100.0f));

            Instantiate(keulen[0], spawnPosition, Quaternion.identity);

            yield return new WaitForSeconds(spawnWait);


        }
    } 

   
}
