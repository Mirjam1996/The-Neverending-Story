﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class EndMenu : MonoBehaviour {

    public Image backgroundImage;
    public bool visible = false; //Sichtbarkeit des Game Over Menüs
    private float transition = 0.0f;

    void Start()
    {
        gameObject.SetActive(false); // Das End Menü soll nur bei erfolgreichem Abschluss sichtbar sein
    }


    void Update()
    {
        if (!visible)
        {
            return;
        }

        transition += Time.deltaTime;
        backgroundImage.color = Color.Lerp(new Color(0, 0, 0, 0), new Color(0, 0, 0, 55), transition);
    }

    public void ToogleEndScreen() // macht das End Menü sichtbar, wird im PlayerStats Skript ausgeführt
    {
        gameObject.SetActive(true);
    }

    public void NewGame() // Button für den Neustart des Spiels
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    public void EndGame() // Button zum Verlassen des Spiels
    {
        Application.Quit();  
    }

}