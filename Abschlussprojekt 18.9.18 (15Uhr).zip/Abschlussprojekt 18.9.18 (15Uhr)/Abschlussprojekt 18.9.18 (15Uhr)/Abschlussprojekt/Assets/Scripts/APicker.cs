﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class APicker : MonoBehaviour {

    public PlayerStats ps; //Hierüber wird späer auf den Hungerwert von "PlayerStats" zugegriffen

    Rigidbody myRigidbody;
    // Use this for initialization

    private void Start()
    {
        myRigidbody = GetComponent<Rigidbody>();
    }

    private void OnTriggerEnter(Collider triggerCollider)
    {
        if(triggerCollider.tag == "apfel"){
            Destroy(triggerCollider.gameObject);
            ps.Hunger = ps.Hunger + 20;
            print("apfel");
        }   
    }

}
