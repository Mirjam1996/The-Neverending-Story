﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Labyrinth : MonoBehaviour {

    public int winkel;
    public int laenge;
	public Vector3 turtlePos;
    public GameObject turtle;
    public Texture mainTexture;
    public BoxCollider myBoxCollider;
    //public GameObject wall;

	// Use this for initialization
	void Start () {
		
        turtle = new GameObject("turtle");

        turtle.transform.position = new Vector3(327.6f, 5.9f, -140.3f);

        myBoxCollider = GetComponent<BoxCollider>();

        Laby(100);
	}
    public void Turn(int winkel)
    {
        //Die Turtle wird um die z-Achse um einen bestimmten Winkel rotiert, der in der Koch1-Funktion übergeben wird
        turtle.transform.Rotate(0.0f, winkel, 0.0f);
    }

    public void Move(int laenge)
    {
        turtle.transform.Translate(laenge / 2, 0.0f, 0.0f);

        GameObject wall = GameObject.CreatePrimitive(PrimitiveType.Cube);

        myBoxCollider.size = new Vector3(laenge, 30.0f, 1.5f);


         wall.transform.localScale = new Vector3(laenge, 30.0f, 1.5f);

        wall.transform.rotation = turtle.transform.rotation;

        wall.transform.position = turtle.transform.position;

        wall.GetComponent<Renderer>().material.color = new Color(0.121f, 0.007f, 0.005f);
        wall.GetComponent<Renderer>().material.SetTexture("_MainTex", mainTexture);

        turtle.transform.Translate(laenge / 2, 0.0f, 0.0f);
    }

    public void Laby(int laenge){

        Move(-laenge +10);

        turtle.transform.position = new Vector3(327.6f - laenge, 5.9f, -140.3f);
        Move(-laenge + 5);
        Turn(-90);
        Move(-laenge + 10);

        turtle.transform.position = new Vector3(327.6f - laenge*2 + 6, 5.9f, -140.3f-laenge);
        Move(-laenge + 5);
        Turn(-90);
        Move(-laenge * 2+5);
        Turn(-90);
        Move(-laenge * 2 + 5);

        turtle.transform.position = new Vector3(327.6f - laenge * 2 + 6, 5.9f, -140.3f - laenge);
        Turn(90);
        Move(-laenge / 2 + 10);

        turtle.transform.position = new Vector3(327.6f - laenge * 2 + 6, 5.9f, -140.3f - laenge + 10);
        Turn(0);
        Move(-laenge / 2 - 10);
        Turn(90);
        Move(-laenge / 2 +10);
        Turn(90);
        Move(-laenge / 2 + 10);
       

        turtle.transform.position = new Vector3(327.6f - laenge * 2 + 56, 5.9f, -140.3f - laenge*2 + 6);
        Turn(90);
        Move(-laenge / 5);
        Turn(-90);
        Move(-laenge / 5 - 10);
        Turn(90);
        Move(-laenge / 5 - 10);
        Turn(90);
        Move(-laenge / 10 );
        Turn(90);
        Move(-laenge / 5);
        Turn(-90);
        Move(-laenge / 5 - 10);
        Turn(90);
        Move(-laenge / 5 - 10);

        turtle.transform.position = new Vector3(327.6f - laenge * 2 + 86, 5.9f, -140.3f - laenge * 2 + 6);
        Turn(180);
        Move(-laenge / 2 +5);
        Turn(-90);
        Move(-laenge / 5 - 10);
        Turn(90);
        Move(-laenge / 10);
        Turn(90);
        Move(-laenge / 2 -30);
        Turn(90);
        Move(-laenge / 10);
        Turn(90);
        Move(-laenge / 2 +10);
        Turn(-90);
        Move(-laenge / 2 + 15);
        Turn(-90);
        Move(-laenge +5);
        Turn(-90);
        Move(-laenge +30);
        Turn(-90);
        Move(-laenge + 20);
        Turn(90);
        Move(-laenge/ 5);
        Turn(90);
        Move(-laenge +10);

        turtle.transform.position = new Vector3(327.6f - laenge * 2 + 112, 5.9f, -140.3f - laenge * 2 + 16);
        Turn(-90);
        Move(-laenge/5);
        Turn(90);
        Move(-laenge/2 - 10);
        Turn(-90);
        Move(-laenge/5 - 5);
        Turn(-90);
        Move(-laenge/10-10);

        turtle.transform.position = new Vector3(327.6f - laenge * 2 + 90, 5.9f, -140.3f - laenge * 2 + 70);
        Turn(0);
        Move(-laenge / 5 - 5);

        turtle.transform.position = new Vector3(327.6f - laenge * 2 + 90, 5.9f, -140.3f - laenge * 2 + 70);
        Turn(90);
        Move(-laenge / 2);
        Turn(-90);
        Move(-laenge +26);
        Turn(90);
        Move(-laenge / 2 -20);
        Turn(90);
        Move(-laenge / 2 + 10);
        Turn(90);
        Move(-laenge / 10 -10);
        Turn(-90);
        Move(-laenge / 10 - 10);
        Turn(-90);
        Move(-laenge / 10 - 10);
        Turn(90);
        Move(-laenge / 5 - 5);
        Turn(-90);
        Move(-laenge / 5 + 10);

        turtle.transform.position = new Vector3(327.6f - laenge + 10, 5.9f, -140.3f);
        Turn(180);
        Move(-laenge / 5 - 5);
        Turn(90);
        Move(-laenge / 5 );
        Turn(-90);
        Move(-laenge / 10 - 10);
        Turn(90);
        Move(-laenge / 2 - 5);
        Turn(90);
        Move(-laenge / 10 - 10);

        turtle.transform.position = new Vector3(327.6f - laenge + 10, 5.9f, -140.3f - laenge / 10 - 14);
        Turn(180);
        Move(-laenge / 2);
        Turn(-90);
        Move(-laenge / 2 -25);
        Turn(-90);
        Move(-laenge / 10);
        Turn(-90);
        Move(-laenge / 2 - 15);
        Turn(90);
        Move(-laenge / 10-20);
        Turn(90);
        Move(-laenge / 10 - 10);
        Turn(-90);
        Move(-laenge / 10 - 10);
        Turn(-90);
        Move(-laenge / 10 - 20);

        turtle.transform.position = new Vector3(327.6f - laenge + 40, 5.9f, -140.3f - laenge / 10 - 4);
        Turn(180);
        Move(-laenge / 2 + 10);

        turtle.transform.position = new Vector3(327.6f - laenge + 40, 5.9f, -140.3f - laenge / 10 - 24);
        Turn(0);
        Move(-laenge / 2 + 10);

        turtle.transform.position = new Vector3(327.6f - laenge - 10, 5.9f, -140.3f - laenge / 2 +6);
        Turn(90);
        Move(-laenge / 2 + 35);
        Turn(90);
        Move(-laenge / 2 -5);

    }

}
