﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterController : MonoBehaviour
{
    public PlayerStats ps; //Hierüber wird auf den Ausdauerwert von "PlayerStats" zugegriffen

    public float inputDelay = 0.1f;
    public float forwardVelocity = 14;
    public float rotateVelocity = 100;

    Quaternion targetRotation;
    Rigidbody rBody;
    float forwardInput, turnInput;

    public Quaternion TargetRotation
    {
        get { return targetRotation; }
    }

    void Start()
    {
        targetRotation = transform.rotation;
        if (GetComponent<Rigidbody>())
            rBody = GetComponent<Rigidbody>();
        else
            Debug.LogError("The character needs a rigidbody.");

        forwardInput = turnInput = 0;
    }

    void GetInput()
    {
        forwardInput = Input.GetAxis("Vertical");
        turnInput = Input.GetAxis("Horizontal");
    }

    void Update()
    {
        GetInput();
        Turn();

        //Sprint- und Ausdauerlogik
        if (Input.GetKey(KeyCode.LeftShift) && ps.Ausdauer > 0) //Durch "ps.Ausdauer > 0" wird sichergestellt, dass Sprinten nur möglich ist, wenn Ausdauer vorhanden ist.
        {
            forwardVelocity = 14;
        }
        else if (ps.Ausdauer <= 0 && ps.Ausdauer >= -4) //Sobald Ausdauer unter 0 rutscht (bzw. zwischen 0 und -4, da 0 nie genau getroffen wird)....
        {
            ps.Ausdauer = -100; //... gibt es quasi eine Straf-Verschnaufpause. Ausdauer springt zu -100, zählt wieder hoch...        
        }
        else if (ps.Ausdauer >= -8 && ps.Ausdauer <= -4 ) //und sobald beim Hochzählen der Beeich zwischen -8 znd -4 getroffen wird....
        {
            ps.Ausdauer = 1; //... springt Ausdauer wieder auf 1 (um den Bereich 0 bis -4 zu überspringen) und man ist wieder "im grünen Bereich" :)
        }
        else
            forwardVelocity = 7; //andernfalls normale Geschwindigkeit
    }

    void FixedUpdate()
    {
        Run();
    }

    void Run()
    {
        if (Mathf.Abs(forwardInput) > inputDelay)
        {
            //move
            rBody.velocity = transform.forward * forwardInput * forwardVelocity;
        }
        else
        {
            //zero.Velocity
            rBody.velocity = Vector3.zero;
        }
    }

    void Turn()
    {
        targetRotation *= Quaternion.AngleAxis(rotateVelocity * turnInput * Time.deltaTime, Vector3.up);
        transform.rotation = targetRotation;

    }

}