﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerStats : MonoBehaviour
{

    public float Health;
    public float healthRecoveryTimer;

    public float Stamina;
    public float staminaOverTime;

    public float Hunger;
    public float hungerOverTime;

    public Slider HealthBar;
    public Slider StaminaBar;
    public Slider HungerBar;

    public float minAmount = 5f;
    public float sprintSpeed = 30f;

    public DeathMenu deathMenu;
    public bool isDead = false;
    Rigidbody myBody;

    private void Start()
    {
        myBody = GetComponent<Rigidbody>();
        HealthBar.maxValue = Health;
        StaminaBar.maxValue = Stamina;
        HungerBar.maxValue = Hunger;

        updateUI();
    }

    private void Update()
    {
        CalculateValues();
    }

    public void CalculateValues()
    {
        Hunger -= hungerOverTime * Time.deltaTime;

        if (Hunger <= 50 && Health >= 3)
        {
            Health = 100 - ((50 - Hunger) * 2);
        }

        if (Hunger >= 80)
        {
            Health += healthRecoveryTimer * Time.deltaTime;
        }


        if (Health < Stamina) {
            Stamina = Health;
        }

        if (myBody.velocity.magnitude >= sprintSpeed && myBody.velocity.y == 0)
        {
            Stamina -= staminaOverTime * Time.deltaTime;
            Hunger -= hungerOverTime * Time.deltaTime * 2;
        }
        else
        {
            Stamina += staminaOverTime * Time.deltaTime;
        }


        if (Hunger <= 0)
        {
            print("Es hat sich ausgefuchst!");
            isDead = true;
        }

        if (isDead)
        {
            deathMenu.ToogleDeathScreen();
        }
        updateUI();
    }

    private void updateUI()
    {
        Health = Mathf.Clamp(Health, 0, 100f);
        Stamina = Mathf.Clamp(Stamina, 0, 100f);
        Hunger = Mathf.Clamp(Hunger, 0, 100f);

        HealthBar.value = Health;
        StaminaBar.value = Stamina;
        HungerBar.value = Hunger;
    }

    public void TakeDamage(float amnt)
    {
        Health -= amnt;
        updateUI();
    }
}