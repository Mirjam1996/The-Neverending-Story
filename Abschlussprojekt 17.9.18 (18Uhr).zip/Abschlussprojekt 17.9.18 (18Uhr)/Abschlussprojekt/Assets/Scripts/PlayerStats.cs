﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; //Für UI-Funktionalitäten

public class PlayerStats : MonoBehaviour
{
    //Float-Werte für die PlayerStats im GUI
    public float Energie;
    public float Ausdauer;
    public float Hunger;

    //Geschwindigkeit, in der Werte zu- bzw. abnehmen
    public float AusdauerOverTime;
    public float HungerOverTime;
    public float EnergieRecoveryTimer;

    //Unity-Slider zur grafischen Darstellung der PlayerStats
    public Slider EnergieBar;
    public Slider AusdauerBar;
    public Slider HungerBar;

    //wichtig um die Sprint-Geschwindigkeit zu erkennen
    public float sprintSpeed = 15f;

    public DeathMenu deathMenu; //Verknüpfung zum Sterbebildschirm
    public bool isDead = false; //Bool, der auch von außerhalb getriggert werden kann (z. B. wenn eine Falle zuschnappt)
    Rigidbody myBody;

    private void Start()
    {
        myBody = GetComponent<Rigidbody>();

        //Den Statusleisten werden Startwerte zugeordnet
        EnergieBar.maxValue = Energie;
        AusdauerBar.maxValue = Ausdauer;
        HungerBar.maxValue = Hunger;

        updateUI(); //UI wird erstmalig aktualisiert
    }

    private void Update()
    {
        Hunger -= HungerOverTime * Time.deltaTime; //Hunger-Wert vermindert sich pro Zeit
        
        if (Hunger <= 50 && Energie >= 10) //Sobald Hunger < 50  und (Energie nicht zu niedrig) sinkt auch die zur Verfügung stehende Energie prozentual:... 
        {
            Energie = 100 - ((50 - Hunger) * 2); //... nämlich Pro Hunger-Punkt zwei Energie-Punkte
        }

        if (Hunger >= 80) // Energie regeneriert sich nur, wenn Hunger fast voll
        {
            Energie += EnergieRecoveryTimer * Time.deltaTime;
        }

        if (myBody.velocity.magnitude >= sprintSpeed && myBody.velocity.y == 0) // falls sich der Fuchs mit Sprintgeschwindigkeit bewegt, aber nicht fällt...
        {
            Ausdauer -= AusdauerOverTime * Time.deltaTime * 2; //...reduziert sich die Ausdauerleiste doppelt...
            Hunger -= HungerOverTime * Time.deltaTime * 2; //...und der Hungerwert auch.
        }
        else
        {
            Ausdauer += AusdauerOverTime * Time.deltaTime; //andernfalls erhöht sich die Ausdauer langsam
        }

        if (Energie < Ausdauer) //Hier wird die maximale Ausdauer durch die Energie begrenzt.
        {
            Ausdauer = Energie;
        }


        if (Hunger <= 0)
        {
            print("Es hat sich ausgefuchst!");
            isDead = true; //falls der Hungerwert unter 0 fällt stirbt der Fuchs
        }

        if (isDead) //Todesbildschirm wird angezeigt.
        {
            deathMenu.ToogleDeathScreen();
        }
        updateUI();
    }

    private void updateUI()
    {
        //Werte werden beschränkt
        Energie = Mathf.Clamp(Energie, 0, 100f);
        Ausdauer = Mathf.Clamp(Ausdauer, -100, 100f); //Ausdauer darf als einziger Wert unter 0 fallen
        Hunger = Mathf.Clamp(Hunger, 0, 100f);

        //PlayerStats werden aktualisiert
        EnergieBar.value = Energie;
        AusdauerBar.value = Ausdauer;
        HungerBar.value = Hunger;
    }

   
}