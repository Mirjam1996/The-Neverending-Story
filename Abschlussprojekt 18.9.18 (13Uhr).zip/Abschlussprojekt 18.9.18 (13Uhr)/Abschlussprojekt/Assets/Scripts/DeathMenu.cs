﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class DeathMenu : MonoBehaviour {

    public Image backgroundImage;
    public bool visible = false; //Sichtbarkeit des Game Over Menüs
    private float transition = 0.0f; 
	 
	void Start ()
    {
        gameObject.SetActive(false); // Das Game Over Menü soll zu Beginn nicht sichtbar sein
	}
	
	 
	void Update ()
    {
		if (!visible)
        {
            return;
        }

        transition += Time.deltaTime;
        backgroundImage.color = Color.Lerp(new Color(0, 0, 0, 0), new Color(0, 0, 0, 55), transition);
	}

    public void ToogleDeathScreen() // macht das Game Over Menü sichtbar, wird im PlayerStats Skript ausgeführt
    {  
        gameObject.SetActive(true); 
    }

    public void NewGame() // Button für den Neustart des Spiels
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    public void EndGame() // Button zum Verlassen des Spiels
    {
        Application.Quit(); 
    }

}

