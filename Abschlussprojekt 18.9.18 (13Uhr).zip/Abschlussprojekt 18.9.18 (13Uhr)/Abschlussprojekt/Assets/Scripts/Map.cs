﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(MeshFilter), typeof(MeshRenderer))]

public class Map : MonoBehaviour
{
    
    //Festlegen der Größe der Map in der xz-Ebene
    public int xSize = 200;
    public int zSize = 200;

    //Vector3 Array namens vtx
    private Vector3[] vtx;

    //Mesh
    private Mesh PMap;



    private void Awake()
    {   //Funktionsaufruf der Mapgenerierungsfunktion
        MapGenerierung();
    }


    private void MapGenerierung()
    {
        //Instanziierung eines Vektor3 Arrays vtx, welches im x- und z- Wert immer eins größer ist, als die vorher festgelegte
        //Mapgröße
        vtx = new Vector3[(xSize + 1) * 1 * (zSize + 1)];

        // Der Mesh Map wird angelegt
        GetComponent<MeshFilter>().mesh = PMap = new Mesh();

        //Der Mesh Map bekommt einen Namen
        PMap.name = "Prozedurale Map";


        //Über zwei for-Schleifen wird das vtx-Array mit Vertices/Punkten befüllt, die sich durch unterschiedliche x- und z-Werte
        //auszeichen
        //Der jeweilige y-Wert eines Punktes so zufällig gewählt werden und in einem Bereich von -0.1f und 1.0f liegen
        //So erhält man eine etwas hügeligere Map/Landschaft
        //In die äußere for-Schleife gelangt man, wenn x den Wert von xSize erreicht
        //Jedem Punkt wird ein Index im vtx Array zugeordnet-->nach jedem Punkt wird i dann hochgezählt
        //i wird in der äußeren for-Schleife defintiert, da der i-Wert, also der Index-Nummer am Ende einer Reihe 
        //von Punkten für die neue Reihe übernommen wird, sodass keine Punkte durch neue Werte überschrieben werden
        //Wenn eine Reihe von Punkten abgearbeitet ist, also wenn x = xSize ist, wird z hochgezählt und eine neue Zeile wird begonnen
        //Es werden so lange Punkte in das Array eingefüllt bis z = zSize und x = xSize sind
        for (int i = 0, z = 0; z <= zSize; z++)
        {
            for (int x = 0; x <= xSize; x++, i++)
            {
                vtx[i] = new Vector3(x, Random.Range(0f, 0.3f), z);
            }
        }

        //Übergabe der Punkte im Array an den Mesh Map
        PMap.vertices = vtx;

        //Anlegen und Instanziieren eines int-Arrays namens triangles zur Speicherung der Dreiecke 
        int[] triangles = new int[xSize * zSize * 6];


        for (int ti = 0, vi = 0, z = 0; z < zSize; z++, vi++)
        {
            for (int x = 0; x < xSize; x++, ti += 6, vi++)
            {
                triangles[ti] = vi;
                triangles[ti + 3] = triangles[ti + 2] = vi + 1;
                triangles[ti + 4] = triangles[ti + 1] = vi + xSize + 1;
                triangles[ti + 5] = vi + xSize + 2;

                //Übergabe der Dreiecke im Array an den Mesh Map
                PMap.triangles = triangles;
                PMap.RecalculateNormals();

            }
        }

    }

    //private void OnDrawGizmos()
    //{
    //    if (vtx == null)
    //    {
    //        return;
    //    }
    //    Gizmos.color = Color.black;
    //    for (int i = 0; i < vtx.Length; i++)
    //    {
    //       Gizmos.DrawSphere(vtx[i], 0.1f);
    //    }
    //}
}



