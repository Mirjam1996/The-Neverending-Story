﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{

    public Transform target;
    public float lookSmooth = 0.15f;
    public Vector3 offsetFromTarget = new Vector3(0, 2, -4); // Entfernung der Kamera zum ausgewählten Ziel, in unserem fall der Fuchs

    Vector3 destination = Vector3.zero;
    CharacterController charController;

    float rotateVelocity = 0;

    void Start()
    {
        SetCameraTarget(target);
    }

    void SetCameraTarget(Transform t)
    {
        target = t;
        if (target != null)  //Überprüfung, ob der Kamere bereits ein Ziel hinzugefügt wurde
        {
            if (target.GetComponent<CharacterController>())  //Überprüfung, ob dem Ziel bereits ein CharacterController hinzugefügt wurde
            {
                charController = target.GetComponent<CharacterController>(); 
            }
            else
                Debug.LogError("The camera's target needs a character controller.");
        }
        else
            Debug.LogError("Your camera needs a target.");   
    }


    void LateUpdate()   
    {
        MoveTotarget();
        LookAtTarget();
    }

    void MoveTotarget()  // Kameraverfolgung des gewählten Ziels
    {
        destination = charController.TargetRotation * offsetFromTarget;
        destination += target.position;
        transform.position = destination;

    }

    void LookAtTarget()   //Ausrichtung der Kamera zum Ziel
    {
        float eulerYAngle = Mathf.SmoothDampAngle(transform.eulerAngles.y, target.eulerAngles.y, ref rotateVelocity, lookSmooth);
        transform.rotation = Quaternion.Euler(transform.eulerAngles.x, eulerYAngle, 0);
    }
}