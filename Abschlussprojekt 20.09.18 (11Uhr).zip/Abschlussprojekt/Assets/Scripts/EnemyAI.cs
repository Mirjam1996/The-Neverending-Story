﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EnemyAI : MonoBehaviour {

    public PlayerStats ps;
    private float distance; // Entfernung vom Bär zum Fuchs
    public Transform target; // Bestimmung der Position des Fuchs
    public float lookAtDistance = 200.0f; //Enfernung auf die der Bär den fuchs anschaut
    public float attackRange = 150.0f; //Radius ab dem der Bär den Fuchs verfolgt
    public float hitRange = 1.5f; //Es hat sich ausgefuchst!
    public float moveSpeed = 15.0f; //Geschwindigkeit des Bärs
    public float smoothness = 7.0f; //Bewegung des Bärs wird etwas smoother

    void Update() {

        distance = Vector3.Distance(target.position, transform.position); //Distanz zwischen Bär und fuchs wird bestimmt

        if (distance < lookAtDistance) //Abfrage, ob der Fuchs in der Sicht des Bären ist
        {
            LookAtTarget();
        }

        if (distance < hitRange) //Abfrage, ob der Fuchs in der unmittelbarer Nähe zum Bären steht und attackiert wird
        { 
            ps.Hunger = 0.0f;
        }

        else if (distance < attackRange) //Abfrage, ob der Fuchs in der Umgebung des Bären ist und dieser ihn verfolgen möchte
        {
            FollowTarget();
        }
    }

    private void LookAtTarget() //Bär dreht sich in Richtung des Fuchs
    {
        Quaternion rotation = Quaternion.LookRotation(target.position - transform.position);
        transform.rotation = Quaternion.Slerp(transform.rotation, rotation, Time.deltaTime * smoothness);
    }

    private void FollowTarget() //Bär verfolgt den Fuchs
    {
        transform.Translate(Vector3.forward * moveSpeed * Time.deltaTime);
    }
    
}
