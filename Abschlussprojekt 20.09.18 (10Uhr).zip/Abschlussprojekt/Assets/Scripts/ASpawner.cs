﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ASpawner : MonoBehaviour {

    public GameObject[] aepfel;
    public GameObject mesh;

    public Vector3 spawnPosition;
    public float spawnWait;
    public int startWait;

  
    // Use this for initialization
    void Start () {

        mesh.transform.localScale = new Vector3(30.0f, 30.0f, 30.0f);
        mesh.transform.Rotate(90.0f, 0.0f, 0.0f);

          
            StartCoroutine(ApfelSpawner());

            
         
	}
	
	// Update is called once per frame
	void Update () {

        spawnWait = 10.0f;


	}

    IEnumerator ApfelSpawner(){

        yield return new WaitForSeconds(startWait);

        while(true){

            spawnPosition = new Vector3(Random.Range(-100.0f, 100.0f), 7.0f, Random.Range(-100.0f, 100.0f));

            Instantiate(aepfel[0], spawnPosition, Quaternion.identity);

            aepfel[0].tag = "apfel";



            yield return new WaitForSeconds(spawnWait);


        }
    } 

   
}
