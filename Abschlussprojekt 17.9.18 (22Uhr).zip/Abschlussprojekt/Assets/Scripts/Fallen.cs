﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fallen : MonoBehaviour {
    
    Rigidbody myRigidbody;
    public bool isDead = false;
    public DeathMenu deathMenu;
    // Use this for initialization

    private void Start()
    {
        myRigidbody = GetComponent<Rigidbody>();
    }

    private void OnTriggerEnter(Collider triggerCollider)
    {
        if(triggerCollider.tag == "blätter" || triggerCollider.tag == "fallen"){
            print("Es hat sich ausgefuchst!");
            isDead = true; //falls der Hungerwert unter 0 fällt stirbt der Fuchs

            if (isDead) //Todesbildschirm wird angezeigt.
            {
                deathMenu.ToogleDeathScreen();
            }
        


        }   
    }

}
