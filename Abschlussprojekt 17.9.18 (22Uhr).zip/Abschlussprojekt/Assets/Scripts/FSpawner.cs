﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FSpawner : MonoBehaviour {

    public GameObject[] fallen;
    public GameObject mesh;

    public Vector3 spawnPosition;
    public float spawnWait;
    public int startWait;

  
    // Use this for initialization
    void Start () {

        mesh.transform.localScale = new Vector3(1.0f, 1.0f, 1.0f);
        mesh.transform.Rotate(90.0f, 0.0f, 0.0f);

        StartCoroutine(FallenSpawner());
    }
	
	// Update is called once per frame
	void Update () {

        spawnWait = 10.0f;


	}

    IEnumerator FallenSpawner(){

        yield return new WaitForSeconds(startWait);

          while(true){

            int i = 0;

            spawnPosition = new Vector3(Random.Range(-100.0f, 100.0f), 7.0f, Random.Range(-100.0f, 100.0f));

            Instantiate(fallen[0], spawnPosition, Quaternion.identity);

            fallen[0].tag = "fallen";

            if(i == 6){
                break;
            }

            i++;

            yield return new WaitForSeconds(spawnWait);


        }
    } 

   
}
